// ##### extgen :: Auto-generated file do not edit!! #####

#pragma once
#import <Foundation/Foundation.h>

@interface GMAppleIAPInternal : NSObject
- (double)__EXT_NATIVE__apple_iap_init:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_can_make_payments;
- (double)__EXT_NATIVE__apple_iap_products:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_product_purchase:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transaction_finish:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transactions_current_entitlement:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transactions_current_entitlements:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transactions_latest:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transactions_unfinished:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_transactions_all:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__apple_iap_synchronize:(char*)__arg_buffer arg1:(double)__arg_buffer_length;
- (double)__EXT_NATIVE__GMAppleIAP_invocation_handler:(char*)__ret_buffer arg1:(double)__ret_buffer_length;
@end


